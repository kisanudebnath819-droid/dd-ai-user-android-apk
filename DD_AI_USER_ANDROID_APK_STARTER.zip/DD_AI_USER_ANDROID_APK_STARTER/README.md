# DD AI USER Android APK Starter

This project builds a simple Android WebView APK for the existing DD AI USER app.

## Important
- The APK opens `http://127.0.0.1:3000` on the same Android phone.
- Keep the DD AI USER Node.js server running in Termux while using the APK.
- This is not a standalone cloud APK. If Termux/server is stopped, the app cannot connect.
- Do not upload `.env`, API keys, passwords, or other secrets to this public repository.

## Build from an Android phone with GitHub
1. Download and extract this ZIP.
2. Create a new **Public** GitHub repository named `dd-ai-user-android-apk`.
3. In the repository choose **Add file → Upload files**.
4. Upload the *contents* of the extracted `DD_AI_USER_ANDROID_APK_STARTER` folder to the repository root. Do not upload only the ZIP or the outer folder.
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab. Select **Build DD AI USER APK**, then **Run workflow**.
7. When the run succeeds, open it and download the `DD-AI-USER-APK` artifact.
8. Extract the artifact ZIP and install `app-debug.apk` on Android.

## Termux server
Start the existing server in Termux:

```bash
cd ~/storage/downloads/DD_Maths_Help_AI
bash start.sh
```

Keep Termux and the server process running, then open the APK.
